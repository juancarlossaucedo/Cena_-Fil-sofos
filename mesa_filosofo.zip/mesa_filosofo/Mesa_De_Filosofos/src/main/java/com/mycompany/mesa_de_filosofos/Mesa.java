package com.mycompany.mesa_de_filosofos;

public class Mesa {
    
    
}
