package com.mycompany.mesa_de_filosofos;

import java.awt.Image;
import static java.lang.Thread.sleep;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

public class interfaz_principal extends javax.swing.JFrame {

    private ImageIcon imagen;
    private ImageIcon icono;
    
    public interfaz_principal() {
        initComponents();
        
        this.setLocationRelativeTo(this);
        
        this.pintarImagen(jLabel1, "image/filosofos.jpg");
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jProgressBar1 = new javax.swing.JProgressBar();
        jProgressBar2 = new javax.swing.JProgressBar();
        jProgressBar3 = new javax.swing.JProgressBar();
        jProgressBar4 = new javax.swing.JProgressBar();
        jProgressBar5 = new javax.swing.JProgressBar();
        jButtonCOMER = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextAreaCHAT = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jProgressBar1, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 10, -1, -1));
        jPanel1.add(jProgressBar2, new org.netbeans.lib.awtextra.AbsoluteConstraints(500, 260, -1, -1));
        jPanel1.add(jProgressBar3, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 430, -1, -1));
        jPanel1.add(jProgressBar4, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 420, -1, -1));
        jPanel1.add(jProgressBar5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 250, -1, -1));

        jButtonCOMER.setBackground(new java.awt.Color(0, 255, 0));
        jButtonCOMER.setFont(new java.awt.Font("sansserif", 1, 18)); // NOI18N
        jButtonCOMER.setForeground(new java.awt.Color(0, 0, 0));
        jButtonCOMER.setText("COMER");
        jButtonCOMER.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jButtonCOMERMouseClicked(evt);
            }
        });
        jPanel1.add(jButtonCOMER, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 230, 110, 50));

        jTextAreaCHAT.setEditable(false);
        jTextAreaCHAT.setColumns(20);
        jTextAreaCHAT.setRows(5);
        jScrollPane1.setViewportView(jTextAreaCHAT);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 0, 250, 140));

        jLabel1.setText("jLabel1");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 40, 600, 380));

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 690, 480));

        pack();
    }// </editor-fold>//GEN-END:initComponents
    private int cont = 1;
    Filosofo mensajeroFilosofo = new Filosofo();
    private void jButtonCOMERMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jButtonCOMERMouseClicked
        do {

            if (cont == 1) {
                //PRIMERO
                mensajeroFilosofo.setFilosofo1("Filósofo 1 comiendo...");
                mensajeroFilosofo.setFilosofo2("Filósofo 2 esperando!");
                mensajeroFilosofo.setFilosofo3("Filósofo 3 esperando!");
                mensajeroFilosofo.setFilosofo4("Filósofo 4 esperando!");
                mensajeroFilosofo.setFilosofo5("Filósofo 5 esperando!");
                this.jTextAreaCHAT.setText(
                        mensajeroFilosofo.getFilosofo1() + "\n"
                        + mensajeroFilosofo.getFilosofo2() + "\n"
                        + mensajeroFilosofo.getFilosofo3() + "\n"
                        + mensajeroFilosofo.getFilosofo4() + "\n"
                        + mensajeroFilosofo.getFilosofo5() + "\n"
                );
                pausa1();
            }

            if (cont == 2) {
                //SEGUNDO
                this.jProgressBar1.setValue(0);
                mensajeroFilosofo.setFilosofo1("Filósofo 1 esperando!");
                mensajeroFilosofo.setFilosofo2("Filósofo 2 comiendo...");
                mensajeroFilosofo.setFilosofo3("Filósofo 3 esperando!");
                mensajeroFilosofo.setFilosofo4("Filósofo 4 esperando!");
                mensajeroFilosofo.setFilosofo5("Filósofo 5 esperando!");
                this.jTextAreaCHAT.setText(
                        mensajeroFilosofo.getFilosofo1() + "\n"
                        + mensajeroFilosofo.getFilosofo2() + "\n"
                        + mensajeroFilosofo.getFilosofo3() + "\n"
                        + mensajeroFilosofo.getFilosofo4() + "\n"
                        + mensajeroFilosofo.getFilosofo5() + "\n"
                );
                pausa2();
            }

            if (cont == 3) {
                //TERCERO
                this.jProgressBar2.setValue(0);
                mensajeroFilosofo.setFilosofo1("Filósofo 1 esperando!");
                mensajeroFilosofo.setFilosofo2("Filósofo 2 esperando!");
                mensajeroFilosofo.setFilosofo3("Filósofo 3 comiendo...");
                mensajeroFilosofo.setFilosofo4("Filósofo 4 esperando!");
                mensajeroFilosofo.setFilosofo5("Filósofo 5 esperando!");
                this.jTextAreaCHAT.setText(
                        mensajeroFilosofo.getFilosofo1() + "\n"
                        + mensajeroFilosofo.getFilosofo2() + "\n"
                        + mensajeroFilosofo.getFilosofo3() + "\n"
                        + mensajeroFilosofo.getFilosofo4() + "\n"
                        + mensajeroFilosofo.getFilosofo5() + "\n"
                );
                pausa3();
            }

            if (cont == 4) {
                //CUARTO
                this.jProgressBar3.setValue(0);
                mensajeroFilosofo.setFilosofo1("Filósofo 1 esperando!");
                mensajeroFilosofo.setFilosofo2("Filósofo 2 esperando!");
                mensajeroFilosofo.setFilosofo3("Filósofo 3 esperando!");
                mensajeroFilosofo.setFilosofo4("Filósofo 4 comiendo...");
                mensajeroFilosofo.setFilosofo5("Filósofo 5 esperando!");
                this.jTextAreaCHAT.setText(
                        mensajeroFilosofo.getFilosofo1() + "\n"
                        + mensajeroFilosofo.getFilosofo2() + "\n"
                        + mensajeroFilosofo.getFilosofo3() + "\n"
                        + mensajeroFilosofo.getFilosofo4() + "\n"
                        + mensajeroFilosofo.getFilosofo5() + "\n"
                );
                pausa4();
            }

            if (cont == 5) {
                //QUINTO
                this.jProgressBar4.setValue(0);
                mensajeroFilosofo.setFilosofo1("Filósofo 1 esperando!");
                mensajeroFilosofo.setFilosofo2("Filósofo 2 esperando!");
                mensajeroFilosofo.setFilosofo3("Filósofo 3 esperando!");
                mensajeroFilosofo.setFilosofo4("Filósofo 4 esperando!");
                mensajeroFilosofo.setFilosofo5("Filósofo 5 comiendo...");
                this.jTextAreaCHAT.setText(
                        mensajeroFilosofo.getFilosofo1() + "\n"
                        + mensajeroFilosofo.getFilosofo2() + "\n"
                        + mensajeroFilosofo.getFilosofo3() + "\n"
                        + mensajeroFilosofo.getFilosofo4() + "\n"
                        + mensajeroFilosofo.getFilosofo5() + "\n"
                );
                pausa5();
            }
            cont++;
        } while (cont == 6);
        this.jProgressBar5.setValue(0);
    }//GEN-LAST:event_jButtonCOMERMouseClicked

    private void pausa1() {
        Thread hilo = new Thread() {
            @Override
            public void run() {
                for (int i = 0; i <= 100; i++) {
                    try {
                        sleep(20);
                        jProgressBar1.setValue(i);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(interfaz_principal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        hilo.start();
    }

    private void pausa2() {
        Thread hilo = new Thread() {
            @Override
            public void run() {
                for (int i = 0; i <= 100; i++) {
                    try {
                        sleep(20);
                        jProgressBar2.setValue(i);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(interfaz_principal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        hilo.start();
    }

    private void pausa3() {
        Thread hilo = new Thread() {
            @Override
            public void run() {
                for (int i = 0; i <= 100; i++) {
                    try {
                        sleep(20);
                        jProgressBar3.setValue(i);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(interfaz_principal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        hilo.start();
    }

    private void pausa4() {
        Thread hilo = new Thread() {
            @Override
            public void run() {
                for (int i = 0; i <= 100; i++) {
                    try {
                        sleep(20);
                        jProgressBar4.setValue(i);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(interfaz_principal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        hilo.start();
    }

    private void pausa5() {
        Thread hilo = new Thread() {
            @Override
            public void run() {
                for (int i = 0; i <= 100; i++) {
                    try {
                        sleep(20);
                        jProgressBar5.setValue(i);
                    } catch (InterruptedException ex) {
                        Logger.getLogger(interfaz_principal.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }
        };
        hilo.start();
    }

    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(interfaz_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(interfaz_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(interfaz_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(interfaz_principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new interfaz_principal().setVisible(true);
            }
        });
    }
    
    private void pintarImagen(JLabel lbl, String ruta){
        this.imagen = new ImageIcon(ruta);
        this.icono = new ImageIcon(
        this.imagen.getImage() .getScaledInstance(
                lbl.getWidth(), lbl.getHeight(), Image.SCALE_DEFAULT)
        ); 
        lbl.setIcon(this.icono);
        this.repaint();
        
    }
     
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonCOMER;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JProgressBar jProgressBar1;
    private javax.swing.JProgressBar jProgressBar2;
    private javax.swing.JProgressBar jProgressBar3;
    private javax.swing.JProgressBar jProgressBar4;
    private javax.swing.JProgressBar jProgressBar5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea jTextAreaCHAT;
    // End of variables declaration//GEN-END:variables

}
