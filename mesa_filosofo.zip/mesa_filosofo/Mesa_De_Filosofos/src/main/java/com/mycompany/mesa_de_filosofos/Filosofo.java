package com.mycompany.mesa_de_filosofos;

public class Filosofo {
    private String filosofo1;
    private String filosofo2;
    private String filosofo3;
    private String filosofo4;
    private String filosofo5;

    public String getFilosofo1() {
        return filosofo1;
    }

    public void setFilosofo1(String filosofo1) {
        this.filosofo1 = filosofo1;
    }

    public String getFilosofo2() {
        return filosofo2;
    }

    public void setFilosofo2(String filosofo2) {
        this.filosofo2 = filosofo2;
    }

    public String getFilosofo4() {
        return filosofo4;
    }

    public void setFilosofo4(String filosofo4) {
        this.filosofo4 = filosofo4;
    }

    public String getFilosofo5() {
        return filosofo5;
    }

    public void setFilosofo5(String filosofo5) {
        this.filosofo5 = filosofo5;
    }

    public String getFilosofo3() {
        return filosofo3;
    }

    public void setFilosofo3(String filosofo3) {
        this.filosofo3 = filosofo3;
    }

}
